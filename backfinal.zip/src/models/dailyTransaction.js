import mongoose from "mongoose";

const dailyTransactionSchema = new mongoose.Schema(
  {
    date: {
      type: String,
      required: true,
    },
    channel: {
      type: String,
      required: false,
      trim: true,
    },
    wallet_id: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "WalletNumber",
      required: false,
    },
    txn_id: {
      type: String,
      required: false,
    },
    client_id: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Client",
      required: false,
    },
    client_name: {
      type: String,
      trim: true,
      required: false,
    },
    number: {
      type: String,
      required: false,
      trim: true,
    },
    type: {
      type: String,
      required: true,
    },
    amount: {
      type: Number,
      required: true,
    },
    fee: {
      type: Number,
      default: 0,
    },
    cost: {
      type: Number,
      default: 0,
    },
    total: {
      type: Number,
      required: false,
    },
    paid: {
      type: Number,
      required: false,
    },
    profit: {
      type: Number,
      default: 0,
    },
    refund: {
      type: Number,
      default: 0,
    },
    due: {
      type: Number,
      default: 0,
    },
    note: {
      type: String,
      trim: true,
    },
    bill_type: {
      type: String,
      trim: true,
    },
    payment_method: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "WalletNumber",
      required: false,
      default: null,
    },
    transaction_id: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Transaction",
      required: true,
    },
    wallet_balance: {
      type: Number,
      required: false,
      default: null,
    },
    meter_number: {
      type: String,
      trim: true,
    },
    customer_number: {
      type: String,
      trim: true,
    },
    customer_name: {
      type: String,
      trim: true,
    },
    bill_fee: {
      type: Number,
      default: 0,
    },
  },

  {
    timestamps: true,
    collection: "daily_transactions",
  }
);

const DailyTransaction = mongoose.model(
  "Daily_Transaction",
  dailyTransactionSchema
);

export default DailyTransaction;
